rm program.jar
ant # Outputs "program.jar" at the top level here
java -jar program.jar

